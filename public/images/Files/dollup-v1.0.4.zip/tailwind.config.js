module.exports = {
  mode: "jit",
  content: [
    "./src/**/**/*.{js,ts,jsx,tsx,html,mdx}",
    "./src/**/*.{js,ts,jsx,tsx,html,mdx}",
  ],
  darkMode: "class",
  theme: {
    screens: { md: { max: "1050px" }, sm: { max: "550px" } },
    extend: {
      colors: {
        gray: {
          100: "#f2f2f2",
          400: "#c4c4c4",
          600: "#828282",
          800: "#504e4e",
          "400_01": "#bdbdbd",
        },
        blue_gray: {
          100: "#d9d9d9",
          700: "#525455",
          900: "#333333",
          "700_11": "#52545511",
          "900_01": "#263238",
          "700_14": "#52545514",
        },
        red: { 600: "#f32020", A400: "#eb0029", "100_3f": "#ffddcc3f" },
        amber: { 300: "#f2c94c" },
        black: {
          900: "#000000",
          "900_3f": "#0000003f",
          "900_01": "#010f1c",
          "900_19": "#00000019",
        },
        white: { A700: "#ffffff" },
      },
      fontFamily: { poppins: "Poppins", rubik: "Rubik" },
      boxShadow: {
        bs1: "0px 4px  4px 0px #0000003f",
        bs: "0px 4px  50px 0px #00000019",
      },
      textShadow: { ts: "0px 4px  4px #0000003f" },
    },
  },
  plugins: [require("@tailwindcss/forms"), require("tailwindcss-textshadow")],
};
