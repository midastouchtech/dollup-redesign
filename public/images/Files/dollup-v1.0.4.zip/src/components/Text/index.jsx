import React from "react";

const sizeClasses = {
  txtPoppinsMedium20Black900: "font-medium font-poppins",
  txtRubikRomanBold46: "font-bold font-rubik",
  txtRubikRomanBold45: "font-bold font-rubik",
  txtPoppinsBold12: "font-bold font-poppins",
  txtRubikRomanMedium50: "font-medium font-rubik",
  txtRubikRomanBold64: "font-bold font-rubik",
  txtPoppinsMedium14: "font-medium font-poppins",
  txtPoppinsMedium16Bluegray900: "font-medium font-poppins",
  txtRubikRomanMedium48: "font-medium font-rubik",
  txtRubikRomanMedium40Bluegray700: "font-medium font-rubik",
  txtRubikRomanSemiBold20: "font-rubik font-semibold",
  txtPoppinsSemiBold18: "font-poppins font-semibold",
  txtPoppinsMedium18: "font-medium font-poppins",
  txtPoppinsMedium15: "font-medium font-poppins",
  txtPoppinsMedium16: "font-medium font-poppins",
  txtRubikRomanRegular32: "font-normal font-rubik",
  txtPoppinsBold28: "font-bold font-poppins",
  txtRubikRomanSemiBold24: "font-rubik font-semibold",
  txtPoppinsBold20: "font-bold font-poppins",
  txtRubikRomanMedium64: "font-medium font-rubik",
  txtRubikRomanMedium40: "font-medium font-rubik",
  txtPoppinsSemiBold24: "font-poppins font-semibold",
  txtPoppinsMedium24: "font-medium font-poppins",
  txtRubikRomanBold96: "font-bold font-rubik",
  txtPoppinsMedium24Bluegray900: "font-medium font-poppins",
  txtRubikRomanMedium32: "font-medium font-rubik",
  txtPoppinsMedium20: "font-medium font-poppins",
  txtPoppinsMedium14Bluegray900: "font-medium font-poppins",
  txtRubikRomanMedium36: "font-medium font-rubik",
  txtPoppinsBold28Gray800: "font-bold font-poppins",
  txtPoppinsMedium16Gray600: "font-medium font-poppins",
  txtPoppinsMedium27: "font-medium font-poppins",
};

const Text = ({ children, className = "", size, as, ...restProps }) => {
  const Component = as || "p";

  return (
    <Component
      className={`text-left ${className} ${size && sizeClasses[size]}`}
      {...restProps}
    >
      {children}
    </Component>
  );
};

export { Text };
