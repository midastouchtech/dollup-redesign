import React from "react";

import { Button, Img, Input, Text } from "components";

const BookingConfirmationPage = () => {
  return (
    <>
      <div className="bg-blue_gray-700_11 flex flex-col font-poppins items-center justify-start mx-auto py-[46px] w-full">
        <div className="flex flex-col gap-14 justify-start w-full">
          <div className="flex md:flex-col flex-row md:gap-5 items-center justify-start md:ml-[0] ml-[95px] md:px-5 w-[67%] md:w-full">
            <div className="flex flex-row gap-[19px] items-center justify-start w-[16%] md:w-full">
              <div className="bg-red-A400 flex flex-col h-[45px] items-center justify-start p-[3px] w-[45px]">
                <div className="flex flex-col items-center justify-start w-[65%] md:w-full">
                  <div className="flex flex-row items-center justify-evenly w-full">
                    <div className="flex flex-col items-start justify-start">
                      <Text
                        className="text-gray-100 text-xs"
                        size="txtPoppinsBold12"
                      >
                        F
                      </Text>
                      <Text
                        className="text-gray-100 text-xs"
                        size="txtPoppinsBold12"
                      >
                        D
                      </Text>
                    </div>
                    <div className="md:h-[19px] h-[37px] relative w-[44%]">
                      <Text
                        className="absolute right-[0] text-gray-100 text-xs top-[0]"
                        size="txtPoppinsBold12"
                      >
                        O
                      </Text>
                      <Text
                        className="absolute bottom-[0] left-[0] text-gray-100 text-xs"
                        size="txtPoppinsBold12"
                      >
                        O
                      </Text>
                    </div>
                  </div>
                </div>
              </div>
              <Text
                className="text-2xl md:text-[22px] text-black-900 sm:text-xl"
                size="txtPoppinsSemiBold24"
              >
                Foodeli
              </Text>
            </div>
            <div className="bg-red-A400 h-1.5 mb-6 md:ml-[0] ml-[150px] md:mt-0 mt-[15px] rounded-[50%] w-1.5"></div>
            <div className="flex sm:flex-col flex-row sm:gap-5 items-start justify-center md:ml-[0] ml-[18px] pr-[5px] w-[45%] md:w-full">
              <Text className="text-red-A400 text-sm" size="txtPoppinsMedium14">
                Home
              </Text>
              <div className="flex flex-col items-center justify-start sm:ml-[0] ml-[25px] w-auto">
                <Text
                  className="text-blue_gray-900 text-sm w-auto"
                  size="txtPoppinsMedium14Bluegray900"
                >
                  About Dollup
                </Text>
              </div>
              <div className="flex flex-col items-center justify-start sm:ml-[0] ml-[30px] w-auto">
                <Text
                  className="text-blue_gray-900 text-sm w-auto"
                  size="txtPoppinsMedium14Bluegray900"
                >
                  Become and Vendor
                </Text>
              </div>
              <Text
                className="sm:ml-[0] ml-[29px] sm:mt-0 mt-0.5 text-blue_gray-900 text-sm"
                size="txtPoppinsMedium14Bluegray900"
              >
                Contact
              </Text>
            </div>
            <Img
              className="h-[22px] md:ml-[0] ml-[182px] w-[22px]"
              src="images/img_search.svg"
              alt="search"
            />
          </div>
          <div className="flex flex-col justify-start w-full">
            <div className="font-rubik h-[382px] ml-0.5 md:ml-[0] md:px-5 relative w-full">
              <Img
                className="h-[382px] m-auto object-cover w-full"
                src="images/img_rectangle20_382x1438.png"
                alt="rectangleTwenty"
              />
              <Text
                className="absolute bottom-[10%] leading-[114.00px] right-[15%] md:text-5xl text-8xl text-center text-shadow-ts text-white-A700 w-[65%] sm:w-full"
                size="txtRubikRomanBold96"
              >
                Booking Confirmation
              </Text>
            </div>
            <div className="bg-white-A700 font-poppins sm:h-11 md:h-52 h-[75px] p-2.5 md:px-5 relative w-full">
              <div className="absolute bottom-[13%] flex md:flex-col flex-row md:gap-5 items-center justify-start left-[2%] md:pr-10 sm:pr-5 pr-[89px] w-[58%]">
                <Text
                  className="text-2xl md:text-[22px] text-red-A400 sm:text-xl"
                  size="txtPoppinsMedium24"
                >
                  Services
                </Text>
                <div className="flex flex-col items-center justify-start md:ml-[0] ml-[103px] w-auto">
                  <Text
                    className="text-2xl md:text-[22px] text-blue_gray-900 sm:text-xl w-auto"
                    size="txtPoppinsMedium24Bluegray900"
                  >
                    About
                  </Text>
                </div>
                <div className="flex flex-col items-center justify-start md:ml-[0] ml-[134px] w-auto">
                  <Text
                    className="text-2xl md:text-[22px] text-blue_gray-900 sm:text-xl w-auto"
                    size="txtPoppinsMedium24Bluegray900"
                  >
                    Location
                  </Text>
                </div>
                <Text
                  className="md:ml-[0] ml-[132px] text-2xl md:text-[22px] text-blue_gray-900 sm:text-xl"
                  size="txtPoppinsMedium24Bluegray900"
                >
                  Reviews
                </Text>
              </div>
              <Text
                className="absolute bottom-[17%] right-[31%] text-2xl md:text-[22px] text-blue_gray-900 sm:text-xl"
                size="txtPoppinsMedium24Bluegray900"
              >
                Add Review
              </Text>
              <div className="absolute border border-black-900 border-solid bottom-[13%] h-11 right-[29%] rounded-[17px] shadow-bs1 w-[13%]"></div>
            </div>
            <Text
              className="md:ml-[0] ml-[536px] mt-[63px] sm:text-[40px] md:text-[46px] text-[50px] text-black-900_01 text-center"
              size="txtRubikRomanMedium50"
            >
              Booking overview
            </Text>
            <Text
              className="bg-white-A700 h-[73px] justify-center max-w-[1138px] md:max-w-full md:ml-[0] ml-[165px] mr-[137px] mt-[39px] sm:px-5 px-[35px] py-3 rounded-[29px] sm:text-4xl md:text-[38px] text-[40px] text-blue_gray-700 w-full"
              size="txtRubikRomanMedium40Bluegray700"
            >
              Service :
            </Text>
            <Text
              className="bg-white-A700 h-[73px] justify-center max-w-[1138px] md:max-w-full md:ml-[0] ml-[163px] mr-[139px] mt-8 sm:px-5 px-[35px] py-3 rounded-[29px] sm:text-4xl md:text-[38px] text-[40px] text-blue_gray-700 w-full"
              size="txtRubikRomanMedium40Bluegray700"
            >
              Price :
            </Text>
            <Text
              className="bg-white-A700 h-[73px] justify-center max-w-[1138px] md:max-w-full md:ml-[0] ml-[156px] mr-[146px] mt-[30px] sm:px-5 px-[35px] py-3 rounded-[29px] sm:text-4xl md:text-[38px] text-[40px] text-blue_gray-700 w-full"
              size="txtRubikRomanMedium40Bluegray700"
            >
              Date :
            </Text>
            <Text
              className="bg-white-A700 h-[73px] justify-center max-w-[1138px] md:max-w-full md:ml-[0] ml-[163px] mr-[139px] mt-[30px] sm:px-5 px-[35px] py-3 rounded-[29px] sm:text-4xl md:text-[38px] text-[40px] text-blue_gray-700 w-full"
              size="txtRubikRomanMedium40Bluegray700"
            >
              Time :
            </Text>
            <Text
              className="bg-white-A700 h-[73px] justify-center md:ml-[0] ml-[565px] mr-[489px] mt-[59px] pb-2 pl-[35px] pr-[22px] pt-4 sm:px-5 rounded-[29px] sm:text-4xl md:text-[38px] text-[40px] text-blue_gray-700 w-[386px]"
              size="txtRubikRomanMedium40Bluegray700"
            >
              Payment Method
            </Text>
            <Text
              className="bg-white-A700 h-[73px] justify-center max-w-[697px] md:max-w-full md:ml-[0] ml-[409px] mr-[334px] mt-[47px] sm:px-5 px-[35px] py-3 rounded-[29px] sm:text-4xl md:text-[38px] text-[40px] text-blue_gray-700 w-full"
              size="txtRubikRomanMedium40Bluegray700"
            >
              Add Voucher :{" "}
            </Text>
            <Text
              className="bg-white-A700 h-[73px] justify-center md:ml-[0] ml-[565px] mr-[489px] mt-[75px] sm:px-5 px-[35px] py-3 rounded-[29px] sm:text-4xl md:text-[38px] text-[40px] text-blue_gray-700 w-[386px]"
              size="txtRubikRomanMedium40Bluegray700"
            >
              Total :{" "}
            </Text>
            <div className="flex md:flex-col flex-row font-rubik gap-[49px] items-center justify-center md:ml-[0] ml-[310px] mt-[68px] md:px-5 w-[58%] md:w-full">
              <Text
                className="bg-white-A700 h-[73px] justify-center md:mt-0 mt-[3px] sm:px-5 px-[35px] py-3 rounded-[29px] sm:text-4xl md:text-[38px] text-[40px] text-blue_gray-700 w-[386px]"
                size="txtRubikRomanMedium40Bluegray700"
              >
                Cash
              </Text>
              <Text
                className="bg-white-A700 h-[73px] justify-center mb-[3px] sm:px-5 px-[35px] py-3 rounded-[29px] sm:text-4xl md:text-[38px] text-[40px] text-blue_gray-700 w-[386px]"
                size="txtRubikRomanMedium40Bluegray700"
              >
                Card
              </Text>
            </div>
            <Button
              className="cursor-pointer font-medium font-poppins h-[76px] md:ml-[0] ml-[531px] mr-[521px] mt-[88px] rounded-[38px] text-4xl sm:text-[32px] md:text-[34px] text-center w-[388px]"
              size="xs"
            >
              Back
            </Button>
            <Text
              className="md:ml-[0] ml-[453px] mt-[42px] md:text-5xl text-[64px] text-black-900_01"
              size="txtRubikRomanMedium64"
            >
              Related Services
            </Text>
            <div className="flex sm:flex-col flex-row sm:gap-5 items-center justify-start max-w-[1388px] mt-[65px] mx-auto md:px-5 w-full">
              <Img
                className="sm:flex-1 h-[219px] md:h-auto object-cover rounded-[30px] w-[19%] sm:w-full"
                src="images/img_frame29.png"
                alt="frameTwentyNine"
              />
              <Img
                className="sm:flex-1 h-[219px] md:h-auto sm:ml-[0] ml-[19px] object-cover rounded-[30px] w-[19%] sm:w-full"
                src="images/img_frame30.png"
                alt="frameThirty"
              />
              <Img
                className="sm:flex-1 h-[219px] md:h-auto sm:ml-[0] ml-[19px] object-cover rounded-[30px] w-[19%] sm:w-full"
                src="images/img_frame31.png"
                alt="frameThirtyOne"
              />
              <Img
                className="sm:flex-1 h-[219px] md:h-auto sm:ml-[0] ml-[34px] object-cover rounded-[30px] w-[19%] sm:w-full"
                src="images/img_frame32.png"
                alt="frameThirtyTwo"
              />
              <Img
                className="sm:flex-1 h-[219px] md:h-auto ml-4 sm:ml-[0] object-cover rounded-[30px] w-[19%] sm:w-full"
                src="images/img_frame33.png"
                alt="frameThirtyThree"
              />
            </div>
            <div className="flex sm:flex-col flex-row font-poppins sm:gap-5 items-start justify-start max-w-[1258px] mt-[9px] mx-auto md:px-5 w-full">
              <Text
                className="sm:mt-0 mt-1 sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                size="txtPoppinsBold28Gray800"
              >
                Make Up{" "}
              </Text>
              <Text
                className="mb-[5px] sm:ml-[0] ml-[157px] sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                size="txtPoppinsBold28Gray800"
              >
                Hair cut
              </Text>
              <Text
                className="mb-[5px] sm:ml-[0] ml-[183px] sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                size="txtPoppinsBold28Gray800"
              >
                Nails
              </Text>
              <Text
                className="mb-[5px] sm:ml-[0] ml-[204px] sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                size="txtPoppinsBold28Gray800"
              >
                Facials
              </Text>
              <Text
                className="sm:ml-[0] ml-[156px] sm:mt-0 mt-[5px] sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                size="txtPoppinsBold28Gray800"
              >
                Massage
              </Text>
            </div>
            <div className="flex md:flex-col flex-row font-rubik md:gap-5 items-center justify-start ml-16 md:ml-[0] mt-[140px] md:px-5 w-[83%] md:w-full">
              <div className="flex flex-row gap-[19px] items-center justify-start mb-1.5 w-[13%] md:w-full">
                <div className="bg-red-A400 flex flex-col font-poppins h-[45px] items-center justify-start p-[3px] w-[45px]">
                  <div className="flex flex-col items-center justify-start w-[65%] md:w-full">
                    <div className="flex flex-row items-center justify-evenly w-full">
                      <div className="flex flex-col items-start justify-start">
                        <Text
                          className="text-gray-100 text-xs"
                          size="txtPoppinsBold12"
                        >
                          F
                        </Text>
                        <Text
                          className="text-gray-100 text-xs"
                          size="txtPoppinsBold12"
                        >
                          D
                        </Text>
                      </div>
                      <div className="md:h-[19px] h-[37px] relative w-[44%]">
                        <Text
                          className="absolute right-[0] text-gray-100 text-xs top-[0]"
                          size="txtPoppinsBold12"
                        >
                          O
                        </Text>
                        <Text
                          className="absolute bottom-[0] left-[0] text-gray-100 text-xs"
                          size="txtPoppinsBold12"
                        >
                          O
                        </Text>
                      </div>
                    </div>
                  </div>
                </div>
                <Text
                  className="text-2xl md:text-[22px] text-black-900 sm:text-xl"
                  size="txtRubikRomanSemiBold24"
                >
                  Foodeli
                </Text>
              </div>
              <Text
                className="md:ml-[0] ml-[235px] text-black-900 text-xl"
                size="txtRubikRomanSemiBold20"
              >
                About
              </Text>
              <Text
                className="md:ml-[0] ml-[97px] text-black-900 text-xl"
                size="txtRubikRomanSemiBold20"
              >
                Company
              </Text>
              <a
                href="javascript:"
                className="md:ml-[0] ml-[122px] text-black-900 text-xl"
              >
                <Text size="txtRubikRomanSemiBold20">Support</Text>
              </a>
              <Text
                className="md:ml-[0] ml-[134px] text-black-900 text-xl"
                size="txtRubikRomanSemiBold20"
              >
                Get in Touch
              </Text>
              <Img
                className="h-[15px] md:ml-[0] ml-[77px] rounded-[3px] w-[15px]"
                src="images/img_user.svg"
                alt="user"
              />
            </div>
            <div className="flex md:flex-col flex-row font-poppins gap-[49px] items-center justify-start ml-16 md:ml-[0] mt-[9px] md:px-5 w-[85%] md:w-full">
              <Text
                className="leading-[30.00px] text-base text-blue_gray-900 w-[28%] sm:w-full"
                size="txtPoppinsMedium16Bluegray900"
              >
                Welcome to Dollup, your ultimate beauty companion designed to
                make your salon experience seamless and stress-free
              </Text>
              <div className="flex flex-col items-start justify-start w-[69%] md:w-full">
                <div className="flex md:flex-col flex-row md:gap-5 items-center justify-start w-[96%] md:w-full">
                  <Text
                    className="text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    About Us
                  </Text>
                  <Text
                    className="md:ml-[0] ml-[85px] text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Vouchers
                  </Text>
                  <Text
                    className="md:ml-[0] ml-[138px] text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Account
                  </Text>
                  <Text
                    className="md:ml-[0] ml-[147px] text-blue_gray-900 text-lg"
                    size="txtPoppinsMedium18"
                  >
                    Question or feedback?
                  </Text>
                </div>
                <div className="flex sm:flex-col flex-row sm:gap-5 items-start justify-start mt-[13px] w-full">
                  <a
                    href="javascript:"
                    className="text-base text-blue_gray-900"
                  >
                    <Text size="txtPoppinsMedium16Bluegray900">Contact US</Text>
                  </a>
                  <Text
                    className="sm:ml-[0] ml-[67px] sm:mt-0 mt-0.5 text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Register Salon
                  </Text>
                  <Text
                    className="sm:ml-[0] ml-[100px] text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    FAQ
                  </Text>
                  <Text
                    className="sm:ml-[0] ml-[182px] text-blue_gray-900 text-lg"
                    size="txtPoppinsMedium18"
                  >
                    We’d love to hear from you
                  </Text>
                </div>
                <div className="flex md:flex-col flex-row md:gap-5 items-start justify-start mt-[15px] w-[95%] md:w-full">
                  <Text
                    className="text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Help
                  </Text>
                  <Text
                    className="md:ml-[0] ml-[121px] text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Become a Partner
                  </Text>
                  <Text
                    className="md:ml-[0] ml-[69px] text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Help
                  </Text>
                  <Input
                    name="frameTwentyFive"
                    placeholder="Email Address"
                    className="p-0 placeholder:text-black-900 text-base text-left w-full"
                    wrapClassName="flex md:ml-[0] ml-[180px] md:mt-0 mt-[17px] w-[196px] md:w-full"
                    type="email"
                    suffix={
                      <Img
                        className="mt-0.5 mb-px h-5 ml-[23px]"
                        src="images/img_carbonsend.svg"
                        alt="carbon:send"
                      />
                    }
                  ></Input>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default BookingConfirmationPage;
