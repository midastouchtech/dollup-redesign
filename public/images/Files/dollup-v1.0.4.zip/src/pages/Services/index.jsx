import React from "react";

import { Button, Img, Input, List, Text } from "components";

const ServicesPage = () => {
  return (
    <>
      <div className="bg-blue_gray-700_11 flex flex-col font-poppins items-center justify-start mx-auto pl-0.5 py-0.5 w-full">
        <div className="flex flex-col items-center justify-start mb-11 mt-[38px] w-full">
          <div className="flex md:flex-col flex-row md:gap-5 items-start justify-start max-w-[1369px] mx-auto md:px-5 w-full">
            <div className="flex md:flex-1 flex-row items-center justify-between w-[27%] md:w-full">
              <div className="flex flex-col items-center justify-start">
                <Text
                  className="text-2xl md:text-[22px] text-black-900 sm:text-xl"
                  size="txtPoppinsSemiBold24"
                >
                  Dollup
                </Text>
              </div>
              <div className="bg-red-A400 h-1.5 mb-2.5 mt-5 rounded-[50%] w-1.5"></div>
            </div>
            <div className="flex md:flex-1 sm:flex-col flex-row sm:gap-5 items-start justify-center md:ml-[0] ml-[18px] md:mt-0 mt-3 pr-[5px] w-[32%] md:w-full">
              <Text className="text-red-A400 text-sm" size="txtPoppinsMedium14">
                Home
              </Text>
              <div className="flex flex-col items-center justify-start sm:ml-[0] ml-[25px] w-auto">
                <Text
                  className="text-blue_gray-900 text-sm w-auto"
                  size="txtPoppinsMedium14Bluegray900"
                >
                  About Dollup
                </Text>
              </div>
              <div className="flex flex-col items-center justify-start sm:ml-[0] ml-[30px] w-auto">
                <Text
                  className="text-blue_gray-900 text-sm w-auto"
                  size="txtPoppinsMedium14Bluegray900"
                >
                  Become and Vendor
                </Text>
              </div>
              <Text
                className="sm:ml-[0] ml-[29px] sm:mt-0 mt-0.5 text-blue_gray-900 text-sm"
                size="txtPoppinsMedium14Bluegray900"
              >
                Contact
              </Text>
            </div>
            <Img
              className="h-[22px] md:ml-[0] ml-[182px] md:mt-0 mt-3 w-[22px]"
              src="images/img_search.svg"
              alt="search"
            />
            <Button
              className="cursor-pointer flex items-center justify-center min-w-[120px] md:ml-[0] ml-[111px] md:mt-0 mt-1"
              leftIcon={
                <Img
                  className="h-4 mt-px mb-1 mr-[5px]"
                  src="images/img_carbonlogin.svg"
                  alt="carbon:login"
                />
              }
              shape="round"
            >
              <div className="font-medium text-left text-sm">Login</div>
            </Button>
            <Button
              className="cursor-pointer flex items-center justify-center min-w-[120px] md:ml-[0] ml-[9px] md:mt-0 mt-1"
              leftIcon={
                <Img
                  className="h-4 mt-px mb-1 mr-[5px]"
                  src="images/img_carbonlogin.svg"
                  alt="carbon:login"
                />
              }
              shape="round"
            >
              <div className="font-medium text-left text-sm">Sign Up</div>
            </Button>
          </div>
          <div className="font-rubik h-[382px] md:h-[435px] mt-[53px] md:px-5 relative w-full">
            <Img
              className="h-[382px] m-auto object-cover w-full"
              src="images/img_rectangle20_382x1438.png"
              alt="rectangleTwenty"
            />
            <Text
              className="absolute bottom-[0] inset-x-[0] leading-[114.00px] mx-auto md:text-5xl text-8xl text-center text-shadow-ts text-white-A700 w-[42%] sm:w-full"
              size="txtRubikRomanBold96"
            >
              Services
            </Text>
          </div>
          <div className="flex flex-col font-rubik gap-[26px] justify-start max-w-[1392px] mt-[102px] mx-auto md:px-5 w-full">
            <Text
              className="ml-2 md:ml-[0] sm:text-[40px] md:text-[46px] text-[50px] text-black-900_01"
              size="txtRubikRomanMedium50"
            >
              Categories
            </Text>
            <div className="flex flex-col justify-start w-full">
              <div className="flex sm:flex-col flex-row sm:gap-10 items-center justify-between w-full">
                <Img
                  className="h-[219px] md:h-auto object-cover rounded-[30px]"
                  src="images/img_frame29.png"
                  alt="frameTwentyNine"
                />
                <Img
                  className="h-[219px] md:h-auto object-cover rounded-[30px]"
                  src="images/img_frame30.png"
                  alt="frameThirty"
                />
                <Img
                  className="h-[219px] md:h-auto object-cover rounded-[30px]"
                  src="images/img_frame31.png"
                  alt="frameThirtyOne"
                />
                <Img
                  className="h-[219px] md:h-auto object-cover rounded-[30px]"
                  src="images/img_frame32.png"
                  alt="frameThirtyTwo"
                />
                <Img
                  className="h-[219px] md:h-auto object-cover rounded-[30px]"
                  src="images/img_frame33.png"
                  alt="frameThirtyThree"
                />
              </div>
              <div className="flex md:flex-col flex-row font-poppins md:gap-5 items-start justify-start md:ml-[0] ml-[84px] mt-[9px] w-[91%] md:w-full">
                <Text
                  className="md:mt-0 mt-1 sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                  size="txtPoppinsBold28Gray800"
                >
                  Make Up{" "}
                </Text>
                <Text
                  className="mb-[5px] md:ml-[0] ml-[157px] sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                  size="txtPoppinsBold28Gray800"
                >
                  Hair cut
                </Text>
                <Text
                  className="mb-[5px] md:ml-[0] ml-[183px] sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                  size="txtPoppinsBold28Gray800"
                >
                  Nails
                </Text>
                <Text
                  className="mb-[5px] md:ml-[0] ml-[204px] sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                  size="txtPoppinsBold28Gray800"
                >
                  Facials
                </Text>
                <Text
                  className="md:ml-[0] ml-[156px] md:mt-0 mt-[5px] sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                  size="txtPoppinsBold28Gray800"
                >
                  Massage
                </Text>
              </div>
              <Text
                className="md:ml-[0] ml-[19px] mt-[76px] sm:text-[40px] md:text-[46px] text-[50px] text-black-900_01"
                size="txtRubikRomanMedium50"
              >
                Beauty Spots Near You
              </Text>
              <div className="flex sm:flex-col flex-row sm:gap-10 items-center justify-between mt-[33px] w-full">
                <Img
                  className="h-[219px] md:h-auto sm:mt-0 mt-[5px] object-cover rounded-[30px]"
                  src="images/img_frame34_219x260.png"
                  alt="frameThirtyFour"
                />
                <Img
                  className="h-[219px] md:h-auto mb-[5px] object-cover rounded-[30px]"
                  src="images/img_frame35_219x260.png"
                  alt="frameThirtyFive"
                />
                <Img
                  className="h-[219px] md:h-auto mb-[5px] object-cover rounded-[30px]"
                  src="images/img_frame36_219x260.png"
                  alt="frameThirtySix"
                />
                <Img
                  className="h-[219px] md:h-auto sm:mt-0 my-0.5 object-cover rounded-[30px]"
                  src="images/img_frame37.png"
                  alt="frameThirtySeven"
                />
                <Img
                  className="h-[219px] md:h-auto sm:mt-0 my-0.5 object-cover rounded-[30px]"
                  src="images/img_frame29.png"
                  alt="frameThirtyEight"
                />
              </div>
              <div className="flex md:flex-col flex-row font-poppins md:gap-10 items-center justify-between ml-2 md:ml-[0] mt-6 w-[96%] md:w-full">
                <List
                  className="sm:flex-col flex-row md:gap-10 gap-[85px] grid sm:grid-cols-1 md:grid-cols-2 grid-cols-3 w-[57%] md:w-full"
                  orientation="horizontal"
                >
                  <div className="sm:h-[55px] h-[60px] sm:ml-[0] sm:mt-0 mt-[5px] relative w-full">
                    <Img
                      className="absolute bottom-[0] h-[13px] right-[21%]"
                      src="images/img_group7_amber_300.svg"
                      alt="groupSeven"
                    />
                    <Text
                      className="absolute inset-x-[0] leading-[1.00px] md:leading-[1px] mx-auto text-gray-800 text-xl top-[0] tracking-[0.20px]"
                      size="txtPoppinsBold20"
                    >
                      <span className="text-gray-800 font-poppins text-left font-bold">
                        <>
                          Legendary Barber
                          <br />
                        </>
                      </span>
                      <span className="text-gray-800 font-poppins text-left font-normal">
                        <>
                          Randburg
                          <br />
                          Rating{" "}
                        </>
                      </span>
                    </Text>
                  </div>
                  <div className="md:h-[59px] h-[61px] mb-1 sm:ml-[0] relative w-full">
                    <Img
                      className="absolute bottom-[0] h-[13px] right-[19%]"
                      src="images/img_group7_amber_300.svg"
                      alt="groupFiftyTwo"
                    />
                    <Text
                      className="absolute inset-x-[0] leading-[1.00px] md:leading-[1px] mx-auto text-gray-800 text-xl top-[0] tracking-[0.20px]"
                      size="txtPoppinsBold20"
                    >
                      <span className="text-gray-800 font-poppins text-left font-bold">
                        <>
                          Fragipani Spa
                          <br />
                        </>
                      </span>
                      <span className="text-gray-800 font-poppins text-left font-normal">
                        <>
                          Randburg
                          <br />
                          Rating{" "}
                        </>
                      </span>
                    </Text>
                  </div>
                  <div className="md:h-[59px] h-[61px] mb-1 sm:ml-[0] relative w-full">
                    <Img
                      className="absolute bottom-[0] h-[13px] right-[17%]"
                      src="images/img_group7_amber_300.svg"
                      alt="groupFiftyThree"
                    />
                    <Text
                      className="absolute inset-x-[0] leading-[1.00px] md:leading-[1px] mx-auto text-gray-800 text-xl top-[0] tracking-[0.20px]"
                      size="txtPoppinsBold20"
                    >
                      <span className="text-gray-800 font-poppins text-left font-bold">
                        <>
                          Spa Club
                          <br />
                        </>
                      </span>
                      <span className="text-gray-800 font-poppins text-left font-normal">
                        <>
                          Randburg
                          <br />
                          Rating{" "}
                        </>
                      </span>
                    </Text>
                  </div>
                </List>
                <List
                  className="sm:flex-col flex-row md:gap-10 gap-[93px] grid sm:grid-cols-1 grid-cols-2 w-[37%] md:w-full"
                  orientation="horizontal"
                >
                  <div className="md:h-[55px] h-[59px] relative w-full">
                    <Img
                      className="absolute bottom-[0] h-[13px] right-[19%]"
                      src="images/img_group7_amber_300.svg"
                      alt="groupFiftyFour"
                    />
                    <Text
                      className="absolute inset-x-[0] leading-[1.00px] md:leading-[1px] mx-auto text-gray-800 text-xl top-[0] tracking-[0.20px]"
                      size="txtPoppinsBold20"
                    >
                      <span className="text-gray-800 font-poppins text-left font-bold">
                        <>
                          Legendary Barber
                          <br />
                        </>
                      </span>
                      <span className="text-gray-800 font-poppins text-left font-normal">
                        <>
                          Randburg
                          <br />
                          Rating{" "}
                        </>
                      </span>
                    </Text>
                  </div>
                  <div className="md:h-[55px] h-[59px] relative w-full">
                    <Img
                      className="absolute bottom-[0] h-[13px] right-[18%]"
                      src="images/img_group7_amber_300.svg"
                      alt="groupFiftyFive"
                    />
                    <Text
                      className="absolute inset-x-[0] leading-[1.00px] md:leading-[1px] mx-auto text-gray-800 text-xl top-[0] tracking-[0.20px]"
                      size="txtPoppinsBold20"
                    >
                      <span className="text-gray-800 font-poppins text-left font-bold">
                        <>
                          Legendary Barber
                          <br />
                        </>
                      </span>
                      <span className="text-gray-800 font-poppins text-left font-normal">
                        <>
                          Randburg
                          <br />
                          Rating{" "}
                        </>
                      </span>
                    </Text>
                  </div>
                </List>
              </div>
              <Text
                className="ml-3 md:ml-[0] mt-[52px] sm:text-[40px] md:text-[46px] text-[50px] text-black-900_01"
                size="txtRubikRomanMedium50"
              >
                Trending Styles
              </Text>
            </div>
          </div>
          <div className="flex flex-col font-rubik justify-start max-w-[1402px] mt-[19px] mx-auto md:px-5 w-full">
            <div className="flex md:flex-col flex-row md:gap-10 items-start justify-between mr-4 w-[99%] md:w-full">
              <Img
                className="h-[219px] md:h-auto md:mt-0 mt-[13px] object-cover rounded-[30px]"
                src="images/img_frame39.png"
                alt="frameThirtyNine"
              />
              <Img
                className="h-[219px] md:h-auto mb-[5px] md:mt-0 mt-2 object-cover rounded-[30px]"
                src="images/img_frame30.png"
                alt="frameForty"
              />
              <Img
                className="h-[219px] md:h-auto mb-[5px] md:mt-0 mt-2 object-cover rounded-[30px]"
                src="images/img_frame41.png"
                alt="frameFortyOne"
              />
              <Img
                className="h-[219px] md:h-auto mb-[13px] object-cover rounded-[30px]"
                src="images/img_frame42.png"
                alt="frameFortyTwo"
              />
              <Img
                className="h-[219px] md:h-auto mb-[13px] object-cover rounded-[30px]"
                src="images/img_frame43.png"
                alt="frameFortyThree"
              />
            </div>
            <div className="flex md:flex-col flex-row font-poppins md:gap-5 items-start justify-start ml-2 md:ml-[0] mt-4 w-[95%] md:w-full">
              <Text
                className="leading-[1.00px] md:leading-[1px] md:mt-0 mt-[13px] text-gray-800 text-xl tracking-[0.20px]"
                size="txtPoppinsBold20"
              >
                <span className="text-gray-800 font-poppins text-left font-bold">
                  <>
                    Legendary Barber
                    <br />
                  </>
                </span>
                <span className="text-gray-800 font-poppins text-left font-normal">
                  <>
                    Randburg
                    <br />
                    Rating{" "}
                  </>
                </span>
              </Text>
              <Text
                className="leading-[1.00px] md:leading-[1px] mb-[5px] md:ml-[0] ml-[85px] md:mt-0 mt-2 text-gray-800 text-xl tracking-[0.20px]"
                size="txtPoppinsBold20"
              >
                <span className="text-gray-800 font-poppins text-left font-bold">
                  <>
                    Legendary Barber
                    <br />
                  </>
                </span>
                <span className="text-gray-800 font-poppins text-left font-normal">
                  <>
                    Randburg
                    <br />
                    Rating{" "}
                  </>
                </span>
              </Text>
              <Text
                className="leading-[1.00px] md:leading-[1px] mb-[5px] md:ml-[0] ml-[85px] md:mt-0 mt-2 text-gray-800 text-xl tracking-[0.20px]"
                size="txtPoppinsBold20"
              >
                <span className="text-gray-800 font-poppins text-left font-bold">
                  <>
                    Legendary Barber
                    <br />
                  </>
                </span>
                <span className="text-gray-800 font-poppins text-left font-normal">
                  <>
                    Randburg
                    <br />
                    Rating{" "}
                  </>
                </span>
              </Text>
              <Text
                className="leading-[1.00px] md:leading-[1px] mb-[13px] md:ml-[0] ml-[93px] text-gray-800 text-xl tracking-[0.20px]"
                size="txtPoppinsBold20"
              >
                <span className="text-gray-800 font-poppins text-left font-bold">
                  <>
                    Legendary Barber
                    <br />
                  </>
                </span>
                <span className="text-gray-800 font-poppins text-left font-normal">
                  <>
                    Randburg
                    <br />
                    Rating{" "}
                  </>
                </span>
              </Text>
              <Text
                className="leading-[1.00px] md:leading-[1px] mb-[13px] md:ml-[0] ml-[93px] text-gray-800 text-xl tracking-[0.20px]"
                size="txtPoppinsBold20"
              >
                <span className="text-gray-800 font-poppins text-left font-bold">
                  <>
                    Legendary Barber
                    <br />
                  </>
                </span>
                <span className="text-gray-800 font-poppins text-left font-normal">
                  <>
                    Randburg
                    <br />
                    Rating{" "}
                  </>
                </span>
              </Text>
            </div>
            <Text
              className="md:ml-[0] ml-[21px] mt-24 sm:text-[40px] md:text-[46px] text-[50px] text-black-900_01"
              size="txtRubikRomanMedium50"
            >
              Top Products
            </Text>
            <div className="flex md:flex-col flex-row md:gap-10 items-center justify-between md:ml-[0] ml-[17px] mt-9 w-[99%] md:w-full">
              <Img
                className="h-[310px] md:h-auto md:mt-0 mt-[11px] object-cover rounded-[30px]"
                src="images/img_frame44.png"
                alt="frameFortyFour"
              />
              <Img
                className="h-[310px] md:h-auto mb-[7px] md:mt-0 mt-1 object-cover rounded-[30px]"
                src="images/img_frame45.png"
                alt="frameFortyFive"
              />
              <Img
                className="h-[310px] md:h-auto mb-[11px] object-cover rounded-[30px]"
                src="images/img_frame46.png"
                alt="frameFortySix"
              />
              <Img
                className="h-[310px] md:h-auto mb-[11px] object-cover rounded-[30px]"
                src="images/img_frame47.png"
                alt="frameFortySeven"
              />
            </div>
            <div className="flex md:flex-col flex-row font-poppins md:gap-5 items-start justify-start ml-0.5 md:ml-[0] mt-[29px] w-[95%] md:w-full">
              <Text
                className="leading-[1.00px] md:leading-[1px] md:mt-0 mt-[70px] text-center text-gray-800 text-xl tracking-[0.20px]"
                size="txtPoppinsBold20"
              >
                <span className="text-gray-800 font-poppins font-bold">
                  <>
                    Lipstick
                    <br />
                  </>
                </span>
                <span className="text-gray-800 font-poppins font-normal">
                  <>
                    Pink Alba
                    <br />
                  </>
                </span>
                <span className="text-red-600 font-poppins font-normal">
                  R 10.00
                </span>
              </Text>
              <Text
                className="leading-[1.00px] md:leading-[1px] md:ml-[0] ml-[124px] md:mt-0 mt-1 text-center text-gray-800 text-xl tracking-[0.20px]"
                size="txtPoppinsBold20"
              >
                <span className="text-gray-800 font-poppins font-bold">
                  <>
                    Lipstick
                    <br />
                  </>
                </span>
                <span className="text-gray-800 font-poppins font-normal">
                  <>
                    Pink Alba
                    <br />
                  </>
                </span>
                <span className="text-red-600 font-poppins font-normal">
                  R 10.00
                </span>
              </Text>
              <Text
                className="leading-[1.00px] md:leading-[1px] md:ml-[0] ml-[101px] text-center text-gray-800 text-xl tracking-[0.20px]"
                size="txtPoppinsBold20"
              >
                <span className="text-gray-800 font-poppins font-bold">
                  <>
                    Lipstick
                    <br />
                  </>
                </span>
                <span className="text-gray-800 font-poppins font-normal">
                  <>
                    Pink Alba
                    <br />
                  </>
                </span>
                <span className="text-red-600 font-poppins font-normal">
                  R 10.00
                </span>
              </Text>
              <Text
                className="leading-[1.00px] md:leading-[1px] md:ml-[0] ml-[100px] text-center text-gray-800 text-xl tracking-[0.20px]"
                size="txtPoppinsBold20"
              >
                <span className="text-gray-800 font-poppins font-bold">
                  <>
                    Lipstick
                    <br />
                  </>
                </span>
                <span className="text-gray-800 font-poppins font-normal">
                  <>
                    Pink Alba
                    <br />
                  </>
                </span>
                <span className="text-red-600 font-poppins font-normal">
                  R 10.00
                </span>
              </Text>
            </div>
            <div className="flex md:flex-col flex-row md:gap-5 items-start justify-start md:ml-[0] ml-[91px] mt-[100px] w-[85%] md:w-full">
              <div className="flex flex-col font-poppins items-center justify-start md:mt-0 my-0.5">
                <Text
                  className="text-2xl md:text-[22px] text-black-900 sm:text-xl"
                  size="txtPoppinsSemiBold24"
                >
                  Dollup
                </Text>
              </div>
              <Text
                className="md:ml-[0] ml-[303px] text-black-900 text-xl"
                size="txtRubikRomanSemiBold20"
              >
                About
              </Text>
              <Text
                className="md:ml-[0] ml-[97px] md:mt-0 mt-0.5 text-black-900 text-xl"
                size="txtRubikRomanSemiBold20"
              >
                Company
              </Text>
              <a
                href="javascript:"
                className="md:ml-[0] ml-[122px] md:mt-0 mt-0.5 text-black-900 text-xl"
              >
                <Text size="txtRubikRomanSemiBold20">Support</Text>
              </a>
              <Text
                className="md:ml-[0] ml-[134px] text-black-900 text-xl"
                size="txtRubikRomanSemiBold20"
              >
                Get in Touch
              </Text>
              <Img
                className="h-[15px] md:ml-[0] ml-[77px] md:mt-0 mt-[25px] rounded-[3px] w-[15px]"
                src="images/img_user.svg"
                alt="user"
              />
            </div>
            <div className="flex md:flex-col flex-row font-poppins gap-[49px] items-center justify-start md:ml-[0] ml-[86px] mt-[9px] w-[87%] md:w-full">
              <Text
                className="leading-[30.00px] text-base text-blue_gray-900 w-[28%] sm:w-full"
                size="txtPoppinsMedium16Bluegray900"
              >
                Welcome to Dollup, your ultimate beauty companion designed to
                make your salon experience seamless and stress-free
              </Text>
              <div className="flex flex-col gap-4 items-start justify-start w-[69%] md:w-full">
                <div className="flex md:flex-col flex-row md:gap-5 items-center justify-start w-[96%] md:w-full">
                  <Text
                    className="text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    About Us
                  </Text>
                  <Text
                    className="md:ml-[0] ml-[85px] text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Vouchers
                  </Text>
                  <Text
                    className="md:ml-[0] ml-[138px] text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Account
                  </Text>
                  <Text
                    className="md:ml-[0] ml-[147px] text-blue_gray-900 text-lg"
                    size="txtPoppinsMedium18"
                  >
                    Question or feedback?
                  </Text>
                </div>
                <div className="flex sm:flex-col flex-row sm:gap-5 items-start justify-start w-full">
                  <a
                    href="javascript:"
                    className="text-base text-blue_gray-900"
                  >
                    <Text size="txtPoppinsMedium16Bluegray900">Contact US</Text>
                  </a>
                  <Text
                    className="sm:ml-[0] ml-[67px] sm:mt-0 mt-0.5 text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Register Salon
                  </Text>
                  <Text
                    className="sm:ml-[0] ml-[100px] text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    FAQ
                  </Text>
                  <Text
                    className="sm:ml-[0] ml-[182px] text-blue_gray-900 text-lg"
                    size="txtPoppinsMedium18"
                  >
                    We’d love to hear from you
                  </Text>
                </div>
                <div className="flex md:flex-col flex-row md:gap-5 items-start justify-start w-[95%] md:w-full">
                  <Text
                    className="text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Help
                  </Text>
                  <Text
                    className="md:ml-[0] ml-[121px] text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Become a Partner
                  </Text>
                  <Text
                    className="md:ml-[0] ml-[69px] text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Help
                  </Text>
                  <Input
                    name="frameTwentyFive"
                    placeholder="Email Address"
                    className="p-0 placeholder:text-black-900 text-base text-left w-full"
                    wrapClassName="flex md:ml-[0] ml-[180px] md:mt-0 mt-[17px] w-[196px] md:w-full"
                    type="email"
                    suffix={
                      <Img
                        className="mt-0.5 mb-px h-5 ml-[23px]"
                        src="images/img_carbonsend.svg"
                        alt="carbon:send"
                      />
                    }
                  ></Input>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ServicesPage;
