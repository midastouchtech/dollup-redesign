import React from "react";

import { Button, Img, Input, Line, Slider, Text } from "components";

const Home1Page = () => {
  const sliderRef = React.useRef(null);
  const [sliderState, setsliderState] = React.useState(0);

  return (
    <>
      <div className="bg-blue_gray-700_14 flex flex-col font-poppins items-center justify-start mx-auto pl-[3px] py-[3px] w-full">
        <div className="flex flex-col justify-start mb-[58px] mt-[50px] w-full">
          <div className="flex md:flex-col flex-row md:gap-5 items-start justify-start ml-24 md:ml-[0] md:px-5 w-[67%] md:w-full">
            <div className="flex flex-col items-center justify-start md:mt-0 mt-[3px]">
              <Text
                className="text-2xl md:text-[22px] text-black-900 sm:text-xl"
                size="txtPoppinsSemiBold24"
              >
                Dollup
              </Text>
            </div>
            <div className="bg-red-A400 h-1.5 mb-[26px] md:ml-[0] ml-[220px] md:mt-0 mt-2 rounded-[50%] w-1.5"></div>
            <div className="flex sm:flex-col flex-row sm:gap-5 items-start justify-center md:ml-[0] ml-[18px] pr-[5px] w-[45%] md:w-full">
              <Text className="text-red-A400 text-sm" size="txtPoppinsMedium14">
                Home
              </Text>
              <div className="flex flex-col items-center justify-start sm:ml-[0] ml-[25px] w-auto">
                <Text
                  className="text-blue_gray-900 text-sm w-auto"
                  size="txtPoppinsMedium14Bluegray900"
                >
                  About Dollup
                </Text>
              </div>
              <div className="flex flex-col items-center justify-start sm:ml-[0] ml-[30px] w-auto">
                <Text
                  className="text-blue_gray-900 text-sm w-auto"
                  size="txtPoppinsMedium14Bluegray900"
                >
                  Become and Vendor
                </Text>
              </div>
              <Text
                className="sm:ml-[0] ml-[29px] sm:mt-0 mt-0.5 text-blue_gray-900 text-sm"
                size="txtPoppinsMedium14Bluegray900"
              >
                Contact
              </Text>
            </div>
            <Img
              className="h-[22px] md:ml-[0] ml-[182px] w-[22px]"
              src="images/img_search.svg"
              alt="search"
            />
          </div>
          <div className="h-[657px] md:h-[700px] mt-[43px] md:px-5 relative w-full">
            <Img
              className="h-[657px] m-auto object-cover w-full"
              src="images/img_rectangle20.png"
              alt="rectangleTwenty"
            />
            <div className="absolute bg-white-A700 flex flex-row sm:gap-10 gap-20 md:h-auto h-max inset-y-[0] items-center justify-center max-w-[698px] my-auto px-[15px] py-[9px] right-[22%] rounded-[35px] shadow-bs w-full">
              <Text
                className="text-base text-black-900 w-auto"
                size="txtPoppinsMedium16"
              >
                Select Service
              </Text>
              <Line className="bg-gray-400 h-[47px] w-px" />
              <Text
                className="text-base text-black-900 w-auto"
                size="txtPoppinsMedium16"
              >
                Enter Location
              </Text>
            </div>
          </div>
          <div className="flex flex-row sm:gap-10 items-start justify-between md:ml-[0] ml-[646px] mt-[119px] md:px-5 w-[37%] md:w-full">
            <Text
              className="mt-1.5 text-lg text-red-A400 tracking-[2.88px]"
              size="txtPoppinsSemiBold18"
            >
              WHAT WE SERVE
            </Text>
            <Img
              className="h-[18px] rounded-[3px] w-[18px]"
              src="images/img_user.svg"
              alt="user"
            />
          </div>
          <div className="flex md:flex-col flex-row font-rubik gap-[11px] items-start justify-center md:ml-[0] ml-[312px] mt-[42px] md:px-5 w-[58%] md:w-full">
            <Img
              className="h-[18px] md:mt-0 mt-[21px] rounded-[3px] w-[18px]"
              src="images/img_thumbsup.svg"
              alt="thumbsup"
            />
            <Text
              className="leading-[52.00px] md:text-3xl sm:text-[28px] text-[32px] text-black-900_01 text-center tracking-[0.32px] w-[97%] sm:w-full"
              size="txtRubikRomanRegular32"
            >
              your ultimate beauty companion designed to make your salon
              experience seamless and stress-free.
            </Text>
          </div>
          <div className="flex md:flex-col flex-row md:gap-5 items-start justify-start max-w-[1174px] mt-[45px] mx-auto md:px-5 w-full">
            <Img
              className="md:flex-1 h-[219px] sm:h-auto mb-0.5 object-cover rounded-[30px] w-[23%] md:w-full"
              src="images/img_frame34.png"
              alt="frameThirtyFour"
            />
            <Button
              className="cursor-pointer flex h-16 items-center justify-center mb-[67px] md:ml-[0] ml-[54px] md:mt-0 mt-[90px] w-16"
              onClick={() => sliderRef.current?.slidePrev?.()}
              shape="circle"
              size="md"
            >
              <Img
                className="h-6"
                src="images/img_arrowright.svg"
                alt="arrowright"
              />
            </Button>
            <Img
              className="md:flex-1 h-[219px] sm:h-auto mb-0.5 md:ml-[0] ml-[74px] object-cover rounded-[30px] w-[23%] md:w-full"
              src="images/img_frame35.png"
              alt="frameThirtyFive"
            />
            <Button
              className="cursor-pointer flex h-16 items-center justify-center mb-[65px] md:ml-[0] ml-[107px] md:mt-0 mt-[92px] w-16"
              onClick={() => sliderRef.current?.slideNext?.()}
              shape="circle"
              size="md"
            >
              <Img
                className="h-6"
                src="images/img_arrowright.svg"
                alt="arrowright_One"
              />
            </Button>
            <Img
              className="md:flex-1 h-[219px] sm:h-auto md:ml-[0] ml-[31px] md:mt-0 mt-0.5 object-cover rounded-[30px] w-[23%] md:w-full"
              src="images/img_frame36.png"
              alt="frameThirtySix"
            />
          </div>
          <div className="flex flex-col items-center justify-start max-w-[1249px] mt-[51px] mx-auto md:px-5 w-full">
            <Slider
              activeIndex={sliderState}
              responsive={{
                0: { items: 1 },
                550: { items: 2 },
                1050: { items: 4 },
              }}
              onSlideChanged={(e) => {
                setsliderState(e?.item);
              }}
              activeSlideCSS="scale-[0.88]"
              magnifiedIndex={1}
              centerMode
              ref={sliderRef}
              className="font-poppins w-full"
              items={[...Array(12)].map(() => (
                <React.Fragment key={Math.random()}>
                  <div className="flex flex-col items-center justify-start mx-2.5">
                    <Text
                      className="leading-[30.00px] text-blue_gray-900 text-center text-lg w-full"
                      size="txtPoppinsMedium18"
                    >
                      Review your selected services, and Confirm your booking
                      and proceed to the payment page.
                    </Text>
                  </div>
                </React.Fragment>
              ))}
            />
            <Text
              className="mt-[125px] md:text-5xl text-[64px] text-black-900_01 text-center"
              size="txtRubikRomanBold64"
            >
              Top Categories
            </Text>
            <div className="flex md:flex-col flex-row md:gap-5 items-center justify-start mt-[102px] w-[90%] md:w-full">
              <Img
                className="h-[219px] sm:h-auto object-cover rounded-[30px] w-[24%] md:w-full"
                src="images/img_frame29.png"
                alt="frameTwentyNine"
              />
              <Img
                className="h-[219px] sm:h-auto md:ml-[0] ml-[19px] object-cover rounded-[30px] w-[24%] md:w-full"
                src="images/img_frame30.png"
                alt="frameThirty"
              />
              <Img
                className="h-[219px] sm:h-auto md:ml-[0] ml-[19px] object-cover rounded-[30px] w-[24%] md:w-full"
                src="images/img_frame31.png"
                alt="frameThirtyOne"
              />
              <Img
                className="h-[219px] sm:h-auto md:ml-[0] ml-[34px] object-cover rounded-[30px] w-[24%] md:w-full"
                src="images/img_frame32.png"
                alt="frameThirtyTwo"
              />
            </div>
            <div className="flex md:flex-col flex-row font-poppins md:gap-5 items-start justify-start mt-[9px] w-[78%] md:w-full">
              <Text
                className="md:mt-0 mt-1 sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                size="txtPoppinsBold28Gray800"
              >
                Make Up{" "}
              </Text>
              <Text
                className="mb-1 md:ml-[0] ml-[157px] sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                size="txtPoppinsBold28Gray800"
              >
                Hair cut
              </Text>
              <Text
                className="mb-1 md:ml-[0] ml-[183px] sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                size="txtPoppinsBold28Gray800"
              >
                Nails
              </Text>
              <Text
                className="mb-1 md:ml-[0] ml-[204px] sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                size="txtPoppinsBold28Gray800"
              >
                Facials
              </Text>
            </div>
            <div className="flex md:flex-col flex-row md:gap-10 items-start justify-between mt-[156px] w-[99%] md:w-full">
              <Img
                className="h-[581px] md:h-auto object-cover"
                src="images/img_rectangle21.png"
                alt="rectangleTwentyOne"
              />
              <div className="flex flex-col items-start justify-start md:mt-0 mt-1">
                <Text
                  className="text-lg text-red-A400 tracking-[2.88px]"
                  size="txtPoppinsSemiBold18"
                >
                  WHAT THEY SAY
                </Text>
                <Text
                  className="leading-[60.00px] mt-[22px] sm:text-[35px] md:text-[41px] text-[45px] text-black-900_01 w-full"
                  size="txtRubikRomanBold45"
                >
                  What Our Customers Say About Us
                </Text>
                <Text
                  className="leading-[30.00px] md:ml-[0] ml-[5px] text-blue_gray-900 text-xl w-[95%] sm:w-full"
                  size="txtPoppinsMedium20"
                >
                  <>
                    &quot;Absolutely amazing! The salon booking system has
                    revolutionized my beauty routine. No more waiting on hold or
                    playing phone tag to secure an appointment. With just a few
                    clicks, I can book my preferred services, select my favorite
                    stylist, and choose a convenient time slot—all from the
                    comfort of my home.
                  </>
                </Text>
                <div className="flex sm:flex-col flex-row font-poppins gap-3.5 items-start justify-start md:ml-[0] ml-[5px] mt-[110px] w-[87%] md:w-full">
                  <Img
                    className="h-16 md:h-auto rounded-[50%] w-16"
                    src="images/img_ellipse9.png"
                    alt="ellipseNine"
                  />
                  <div className="flex flex-col items-start justify-start w-[84%] sm:w-full">
                    <Text
                      className="text-black-900 text-xl"
                      size="txtPoppinsMedium20Black900"
                    >
                      Theresa Jordan
                    </Text>
                    <div className="flex flex-row items-start justify-between mt-[3px] w-full">
                      <Text
                        className="text-base text-gray-600"
                        size="txtPoppinsMedium16Gray600"
                      >
                        Food Enthusiast
                      </Text>
                      <Img
                        className="h-[15px] rounded-[3px] w-[15px]"
                        src="images/img_user.svg"
                        alt="user_One"
                      />
                    </div>
                  </div>
                </div>
                <div className="flex flex-row font-poppins gap-[42px] items-start justify-start md:ml-[0] ml-[5px] mt-[34px] w-[45%] md:w-full">
                  <Img
                    className="h-6 mt-[3px]"
                    src="images/img_group7.svg"
                    alt="groupSeven"
                  />
                  <Text
                    className="h-[23px] text-[15px] text-black-900"
                    size="txtPoppinsMedium15"
                  >
                    4,8
                  </Text>
                </div>
              </div>
            </div>
          </div>
          <div className="bg-red-100_3f flex flex-col font-poppins md:gap-10 gap-[78px] justify-center max-w-[1250px] mt-[123px] mx-auto p-[73px] md:px-5 rounded-[30px] w-full">
            <div className="flex flex-col items-start justify-start ml-3 md:ml-[0] mr-[658px] mt-[45px]">
              <Text
                className="text-lg text-red-A400 tracking-[2.88px]"
                size="txtPoppinsSemiBold18"
              >
                DOWNLOAD APP
              </Text>
              <Text
                className="leading-[60.00px] mt-[22px] sm:text-4xl md:text-[42px] text-[46px] text-black-900_01 w-[94%] sm:w-full"
                size="txtRubikRomanBold46"
              >
                Get Started With Dollup Today!
              </Text>
              <Text
                className="leading-[30.00px] mt-[18px] text-blue_gray-900 text-lg w-full"
                size="txtPoppinsMedium18"
              >
                Book appointments for haircuts, coloring, styling, manicures,
                pedicures, facials, and more with just a few taps.
              </Text>
            </div>
            <Button
              className="!text-white-A700 cursor-pointer font-medium h-[68px] mb-1.5 mr-[903px] rounded-[34px] text-center text-lg w-[201px]"
              size="md"
            >
              Get The App
            </Button>
          </div>
          <div className="flex md:flex-col flex-row md:gap-5 items-start justify-start md:ml-[0] ml-[126px] mt-[133px] md:px-5 w-[76%] md:w-full">
            <div className="flex flex-col font-poppins items-center justify-start md:mt-0 mt-[3px]">
              <Text
                className="text-2xl md:text-[22px] text-black-900 sm:text-xl"
                size="txtPoppinsSemiBold24"
              >
                Dollup
              </Text>
            </div>
            <Text
              className="md:ml-[0] ml-[301px] text-black-900 text-xl"
              size="txtRubikRomanSemiBold20"
            >
              About
            </Text>
            <Text
              className="md:ml-[0] ml-[97px] md:mt-0 mt-0.5 text-black-900 text-xl"
              size="txtRubikRomanSemiBold20"
            >
              Company
            </Text>
            <a
              href="javascript:"
              className="md:ml-[0] ml-[122px] md:mt-0 mt-0.5 text-black-900 text-xl"
            >
              <Text size="txtRubikRomanSemiBold20">Support</Text>
            </a>
            <Text
              className="md:ml-[0] ml-[134px] text-black-900 text-xl"
              size="txtRubikRomanSemiBold20"
            >
              Get in Touch
            </Text>
          </div>
          <div className="flex md:flex-col flex-row font-poppins gap-[49px] items-start justify-start max-w-[1217px] mt-2.5 mx-auto md:px-5 w-full">
            <div className="flex md:flex-1 flex-col gap-2.5 justify-start md:mt-0 mt-3.5 w-[28%] md:w-full">
              <Text
                className="leading-[30.00px] text-base text-blue_gray-900 w-full"
                size="txtPoppinsMedium16Bluegray900"
              >
                Welcome to Dollup, your ultimate beauty companion designed to
                make your salon experience seamless and stress-free
              </Text>
              <div className="flex flex-row gap-10 items-start justify-start ml-3 md:ml-[0] w-[46%] md:w-full">
                <Img
                  className="h-6 w-6"
                  src="images/img_bxbxlinstagramalt.svg"
                  alt="bxbxlinstagrama"
                />
                <Img
                  className="h-6 w-6"
                  src="images/img_bxbxlfacebook.svg"
                  alt="bxbxlfacebook"
                />
                <Img
                  className="h-6 w-6"
                  src="images/img_akariconstwitterfill.svg"
                  alt="akariconstwitte"
                />
              </div>
            </div>
            <div className="flex md:flex-1 flex-col gap-4 items-start justify-start w-[69%] md:w-full">
              <div className="flex md:flex-col flex-row md:gap-5 items-center justify-start w-[96%] md:w-full">
                <Text
                  className="text-base text-blue_gray-900"
                  size="txtPoppinsMedium16Bluegray900"
                >
                  About Us
                </Text>
                <Text
                  className="md:ml-[0] ml-[85px] text-base text-blue_gray-900"
                  size="txtPoppinsMedium16Bluegray900"
                >
                  Vouchers
                </Text>
                <Text
                  className="md:ml-[0] ml-[138px] text-base text-blue_gray-900"
                  size="txtPoppinsMedium16Bluegray900"
                >
                  Account
                </Text>
                <Text
                  className="md:ml-[0] ml-[147px] text-blue_gray-900 text-lg"
                  size="txtPoppinsMedium18"
                >
                  Question or feedback?
                </Text>
              </div>
              <div className="flex sm:flex-col flex-row sm:gap-5 items-start justify-start w-full">
                <a href="javascript:" className="text-base text-blue_gray-900">
                  <Text size="txtPoppinsMedium16Bluegray900">Contact US</Text>
                </a>
                <Text
                  className="sm:ml-[0] ml-[67px] sm:mt-0 mt-0.5 text-base text-blue_gray-900"
                  size="txtPoppinsMedium16Bluegray900"
                >
                  Register Salon
                </Text>
                <Text
                  className="sm:ml-[0] ml-[100px] text-base text-blue_gray-900"
                  size="txtPoppinsMedium16Bluegray900"
                >
                  FAQ
                </Text>
                <Text
                  className="sm:ml-[0] ml-[182px] text-blue_gray-900 text-lg"
                  size="txtPoppinsMedium18"
                >
                  We’d love to hear from you
                </Text>
              </div>
              <div className="flex md:flex-col flex-row md:gap-5 items-start justify-start w-[95%] md:w-full">
                <Text
                  className="text-base text-blue_gray-900"
                  size="txtPoppinsMedium16Bluegray900"
                >
                  Help
                </Text>
                <Text
                  className="md:ml-[0] ml-[121px] text-base text-blue_gray-900"
                  size="txtPoppinsMedium16Bluegray900"
                >
                  Become a Partner
                </Text>
                <Text
                  className="md:ml-[0] ml-[69px] text-base text-blue_gray-900"
                  size="txtPoppinsMedium16Bluegray900"
                >
                  Help
                </Text>
                <Input
                  name="frameTwentyFive"
                  placeholder="Email Address"
                  className="p-0 placeholder:text-black-900 text-base text-left w-full"
                  wrapClassName="flex md:ml-[0] ml-[180px] md:mt-0 mt-[17px] w-[196px] md:w-full"
                  type="email"
                  suffix={
                    <Img
                      className="mt-0.5 mb-px h-5 ml-[23px]"
                      src="images/img_carbonsend.svg"
                      alt="carbon:send"
                    />
                  }
                ></Input>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Home1Page;
