import React from "react";

import { Button, Img, Input, List, Text } from "components";

const BookingPage = () => {
  return (
    <>
      <div className="bg-blue_gray-700_11 flex flex-col font-poppins items-center justify-end mx-auto py-[25px] w-full">
        <div className="flex flex-col gap-14 items-center justify-start mt-3 w-full">
          <div className="flex md:flex-col flex-row md:gap-5 items-end justify-start max-w-[1301px] mx-auto md:px-5 w-full">
            <div className="flex md:flex-1 flex-row gap-[19px] items-center justify-start md:mt-0 mt-[9px] w-[12%] md:w-full">
              <div className="bg-red-A400 flex flex-col h-[45px] items-center justify-start p-[3px] w-[45px]">
                <div className="flex flex-col items-center justify-start w-[65%] md:w-full">
                  <div className="flex flex-row items-center justify-evenly w-full">
                    <div className="flex flex-col items-start justify-start">
                      <Text
                        className="text-gray-100 text-xs"
                        size="txtPoppinsBold12"
                      >
                        F
                      </Text>
                      <Text
                        className="text-gray-100 text-xs"
                        size="txtPoppinsBold12"
                      >
                        D
                      </Text>
                    </div>
                    <div className="md:h-[19px] h-[37px] relative w-[44%]">
                      <Text
                        className="absolute right-[0] text-gray-100 text-xs top-[0]"
                        size="txtPoppinsBold12"
                      >
                        O
                      </Text>
                      <Text
                        className="absolute bottom-[0] left-[0] text-gray-100 text-xs"
                        size="txtPoppinsBold12"
                      >
                        O
                      </Text>
                    </div>
                  </div>
                </div>
              </div>
              <Text
                className="text-2xl md:text-[22px] text-black-900 sm:text-xl"
                size="txtPoppinsSemiBold24"
              >
                Foodeli
              </Text>
            </div>
            <div className="bg-red-A400 h-1.5 md:ml-[0] ml-[150px] md:mt-0 my-6 rounded-[50%] w-1.5"></div>
            <div className="flex md:flex-1 sm:flex-col flex-row sm:gap-5 items-start justify-center md:ml-[0] ml-[18px] md:mt-0 my-[15px] pr-[5px] w-[33%] md:w-full">
              <Text className="text-red-A400 text-sm" size="txtPoppinsMedium14">
                Home
              </Text>
              <div className="flex flex-col items-center justify-start sm:ml-[0] ml-[25px] w-auto">
                <Text
                  className="text-blue_gray-900 text-sm w-auto"
                  size="txtPoppinsMedium14Bluegray900"
                >
                  About Dollup
                </Text>
              </div>
              <div className="flex flex-col items-center justify-start sm:ml-[0] ml-[30px] w-auto">
                <Text
                  className="text-blue_gray-900 text-sm w-auto"
                  size="txtPoppinsMedium14Bluegray900"
                >
                  Become and Vendor
                </Text>
              </div>
              <Text
                className="sm:ml-[0] ml-[29px] sm:mt-0 mt-0.5 text-blue_gray-900 text-sm"
                size="txtPoppinsMedium14Bluegray900"
              >
                Contact
              </Text>
            </div>
            <div className="flex md:flex-1 flex-row gap-[97px] items-center justify-center mb-[5px] md:ml-[0] ml-[182px] w-[19%] md:w-full">
              <Img
                className="h-[22px] w-[22px]"
                src="images/img_search.svg"
                alt="search"
              />
              <Button
                className="cursor-pointer flex items-center justify-center min-w-[120px]"
                leftIcon={
                  <Img
                    className="h-4 mt-px mb-1 mr-[5px]"
                    src="images/img_carbonlogin.svg"
                    alt="carbon:login"
                  />
                }
                shape="round"
              >
                <div className="font-medium text-left text-sm">Login</div>
              </Button>
            </div>
            <Button
              className="cursor-pointer flex items-center justify-center mb-[5px] min-w-[120px] md:ml-[0] ml-[9px]"
              leftIcon={
                <Img
                  className="h-4 mt-px mb-1 mr-[5px]"
                  src="images/img_carbonlogin.svg"
                  alt="carbon:login"
                />
              }
              shape="round"
            >
              <div className="font-medium text-left text-sm">Sign Up</div>
            </Button>
          </div>
          <div className="flex flex-col justify-start w-full">
            <div className="font-rubik h-[382px] ml-0.5 md:ml-[0] md:px-5 relative w-full">
              <Img
                className="h-[382px] m-auto object-cover w-full"
                src="images/img_rectangle20_382x1438.png"
                alt="rectangleTwenty"
              />
              <Text
                className="absolute bottom-[0] inset-x-[0] leading-[114.00px] mx-auto md:text-5xl text-8xl text-center text-shadow-ts text-white-A700 w-[42%] sm:w-full"
                size="txtRubikRomanBold96"
              >
                Booking
              </Text>
            </div>
            <div className="bg-white-A700 font-poppins md:h-11 h-[75px] p-2.5 md:px-5 relative w-full">
              <div className="absolute bottom-[13%] flex flex-row items-center justify-between left-[2%] px-1.5 w-[58%]">
                <Text
                  className="text-2xl md:text-[22px] text-red-A400 sm:text-xl"
                  size="txtPoppinsMedium24"
                >
                  {" "}
                  Book
                </Text>
                <div className="flex flex-col items-center justify-start w-auto">
                  <Text
                    className="text-2xl md:text-[22px] text-blue_gray-900 sm:text-xl w-auto"
                    size="txtPoppinsMedium24Bluegray900"
                  >
                    About
                  </Text>
                </div>
                <div className="flex flex-col items-center justify-start w-auto">
                  <Text
                    className="text-2xl md:text-[22px] text-blue_gray-900 sm:text-xl w-auto"
                    size="txtPoppinsMedium24Bluegray900"
                  >
                    Location
                  </Text>
                </div>
                <Text
                  className="mr-[82px] text-2xl md:text-[22px] text-blue_gray-900 sm:text-xl"
                  size="txtPoppinsMedium24Bluegray900"
                >
                  Reviews
                </Text>
              </div>
              <Text
                className="absolute bottom-[17%] right-[31%] text-2xl md:text-[22px] text-blue_gray-900 sm:text-xl"
                size="txtPoppinsMedium24Bluegray900"
              >
                Add Review
              </Text>
              <div className="absolute border border-black-900 border-solid bottom-[13%] h-11 right-[29%] rounded-[17px] shadow-bs1 w-[13%]"></div>
            </div>
            <Text
              className="md:ml-[0] ml-[595px] mt-[91px] md:text-5xl text-[64px] text-black-900_01"
              size="txtRubikRomanMedium64"
            >
              Services
            </Text>
            <div className="flex sm:flex-col flex-row sm:gap-5 items-center justify-start max-w-[1388px] mt-[38px] mx-auto md:px-5 w-full">
              <Img
                className="sm:flex-1 h-[219px] md:h-auto object-cover rounded-[30px] w-[19%] sm:w-full"
                src="images/img_frame29.png"
                alt="frameFiftyOne"
              />
              <Img
                className="sm:flex-1 h-[219px] md:h-auto sm:ml-[0] ml-[19px] object-cover rounded-[30px] w-[19%] sm:w-full"
                src="images/img_frame30.png"
                alt="frameFiftyTwo"
              />
              <Img
                className="sm:flex-1 h-[219px] md:h-auto sm:ml-[0] ml-[19px] object-cover rounded-[30px] w-[19%] sm:w-full"
                src="images/img_frame31.png"
                alt="frameFiftyThree"
              />
              <Img
                className="sm:flex-1 h-[219px] md:h-auto sm:ml-[0] ml-[34px] object-cover rounded-[30px] w-[19%] sm:w-full"
                src="images/img_frame32.png"
                alt="frameFiftyFour"
              />
              <Img
                className="sm:flex-1 h-[219px] md:h-auto ml-4 sm:ml-[0] object-cover rounded-[30px] w-[19%] sm:w-full"
                src="images/img_frame33.png"
                alt="frameThirtyThree"
              />
            </div>
            <div className="flex md:flex-col flex-row font-poppins md:gap-10 items-center justify-between max-w-[1320px] mt-2 mx-auto md:px-5 w-full">
              <List
                className="sm:flex-col flex-row md:gap-10 gap-24 grid sm:grid-cols-1 md:grid-cols-2 grid-cols-4"
                orientation="horizontal"
              >
                <div className="h-[58px] sm:ml-[0] relative w-full">
                  <Text
                    className="m-auto sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                    size="txtPoppinsBold28Gray800"
                  >
                    Hair cut
                  </Text>
                  <div className="absolute border border-black-900 border-solid h-[58px] inset-[0] justify-center m-auto rounded-[29px] w-full"></div>
                </div>
                <div className="h-[58px] sm:ml-[0] relative w-full">
                  <Text
                    className="mt-[3px] mx-auto sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                    size="txtPoppinsBold28Gray800"
                  >
                    Hair cut
                  </Text>
                  <div className="absolute border border-black-900 border-solid h-[58px] inset-[0] justify-center m-auto rounded-[29px] w-full"></div>
                </div>
                <div className="h-[58px] sm:ml-[0] relative w-full">
                  <Text
                    className="mt-1 mx-auto sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                    size="txtPoppinsBold28Gray800"
                  >
                    Nails
                  </Text>
                  <div className="absolute border border-black-900 border-solid h-[58px] inset-[0] justify-center m-auto rounded-[29px] w-full"></div>
                </div>
                <div className="h-[58px] sm:ml-[0] relative w-full">
                  <Text
                    className="mx-auto sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                    size="txtPoppinsBold28Gray800"
                  >
                    Facials
                  </Text>
                  <div className="absolute border border-black-900 border-solid h-[58px] inset-[0] justify-center m-auto rounded-[29px] w-full"></div>
                </div>
              </List>
              <Button
                className="cursor-pointer font-bold min-w-[189px] rounded-[29px] sm:text-2xl md:text-[26px] text-[28px] text-center tracking-[0.28px]"
                color="black_900"
                size="xs"
                variant="outline"
              >
                Massage
              </Button>
            </div>
            <div className="flex sm:flex-col flex-row sm:gap-5 items-center justify-start max-w-[1379px] mt-[71px] mx-auto md:px-5 w-full">
              <Img
                className="sm:flex-1 h-[219px] md:h-auto object-cover rounded-[30px] w-[19%] sm:w-full"
                src="images/img_frame31.png"
                alt="frameFiftySeven"
              />
              <Img
                className="sm:flex-1 h-[219px] md:h-auto sm:ml-[0] ml-[34px] object-cover rounded-[30px] w-[19%] sm:w-full"
                src="images/img_frame32.png"
                alt="frameFiftyEight"
              />
              <Img
                className="sm:flex-1 h-[219px] md:h-auto ml-4 sm:ml-[0] object-cover rounded-[30px] w-[19%] sm:w-full"
                src="images/img_frame33.png"
                alt="frameFiftyNine"
              />
              <Img
                className="sm:flex-1 h-[219px] md:h-auto ml-2.5 sm:ml-[0] object-cover rounded-[30px] w-[19%] sm:w-full"
                src="images/img_frame29.png"
                alt="frameFiftyFive"
              />
              <Img
                className="sm:flex-1 h-[219px] md:h-auto sm:ml-[0] ml-[19px] object-cover rounded-[30px] w-[19%] sm:w-full"
                src="images/img_frame30.png"
                alt="frameFiftySix"
              />
            </div>
            <List
              className="sm:flex-col flex-row font-poppins md:gap-10 gap-[108px] grid sm:grid-cols-1 md:grid-cols-3 grid-cols-5 justify-center max-w-[1323px] mt-1.5 mx-auto md:px-5 w-full"
              orientation="horizontal"
            >
              <div className="h-[58px] relative w-full">
                <Text
                  className="mt-1 mx-auto sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                  size="txtPoppinsBold28Gray800"
                >
                  Nails
                </Text>
                <div className="absolute border border-black-900 border-solid h-[58px] inset-[0] justify-center m-auto rounded-[29px] w-full"></div>
              </div>
              <div className="h-[58px] relative w-full">
                <Text
                  className="mt-[5px] mx-auto sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                  size="txtPoppinsBold28Gray800"
                >
                  Facials
                </Text>
                <div className="absolute border border-black-900 border-solid h-[58px] inset-[0] justify-center m-auto rounded-[29px] w-full"></div>
              </div>
              <div className="flex h-[58px] justify-end relative w-full">
                <Text
                  className="mb-[5px] ml-auto mr-[21px] mt-auto sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                  size="txtPoppinsBold28Gray800"
                >
                  Massage
                </Text>
                <div className="absolute border border-black-900 border-solid h-[58px] inset-[0] justify-center m-auto rounded-[29px] w-full"></div>
              </div>
              <div className="flex h-[58px] justify-end relative w-full">
                <Text
                  className="mb-[5px] ml-auto mr-[26px] mt-auto sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                  size="txtPoppinsBold28Gray800"
                >
                  Make Up{" "}
                </Text>
                <div className="absolute border border-black-900 border-solid h-[58px] inset-[0] justify-center m-auto rounded-[29px] w-full"></div>
              </div>
              <div className="h-[58px] relative w-full">
                <Text
                  className="m-auto sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                  size="txtPoppinsBold28Gray800"
                >
                  Hair cut
                </Text>
                <div className="absolute border border-black-900 border-solid h-[58px] inset-[0] justify-center m-auto rounded-[29px] w-full"></div>
              </div>
            </List>
            <div className="flex sm:flex-col flex-row font-rubik sm:gap-5 items-start justify-start max-w-[1386px] mt-[101px] mx-auto md:px-5 w-full">
              <Text
                className="sm:mt-0 mt-[86px] text-5xl sm:text-[38px] md:text-[44px] text-black-900_01"
                size="txtRubikRomanMedium48"
              >
                Choose Expert
              </Text>
              <Img
                className="sm:flex-1 h-[190px] md:h-auto sm:ml-[0] ml-[65px] object-cover rounded-[30px] w-[17%] sm:w-full"
                src="images/img_frame29.png"
                alt="frameThirtyNine"
              />
              <Img
                className="sm:flex-1 h-[190px] md:h-auto sm:ml-[0] ml-[17px] object-cover rounded-[30px] w-[17%] sm:w-full"
                src="images/img_frame29.png"
                alt="frameForty"
              />
              <Img
                className="sm:flex-1 h-[190px] md:h-auto ml-4 sm:ml-[0] object-cover rounded-[30px] w-[17%] sm:w-full"
                src="images/img_frame29.png"
                alt="frameFortyOne"
              />
              <Img
                className="sm:flex-1 h-[190px] md:h-auto sm:ml-[0] ml-[29px] object-cover rounded-[30px] w-[17%] sm:w-full"
                src="images/img_frame29.png"
                alt="frameFortyTwo"
              />
            </div>
            <List
              className="sm:flex-col flex-row font-poppins md:gap-10 gap-[62px] grid sm:grid-cols-1 md:grid-cols-2 grid-cols-4 md:ml-[0] ml-[458px] mt-1 md:px-5 w-[65%]"
              orientation="horizontal"
            >
              <div className="h-[58px] relative w-full">
                <Text
                  className="ml-auto mr-[26px] mt-[5px] sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                  size="txtPoppinsBold28Gray800"
                >
                  Miranda
                </Text>
                <div className="absolute border border-black-900 border-solid h-[58px] inset-[0] justify-center m-auto rounded-[29px] w-full"></div>
              </div>
              <div className="h-[58px] relative w-full">
                <Text
                  className="mt-[5px] mx-auto sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                  size="txtPoppinsBold28Gray800"
                >
                  Thandiwe
                </Text>
                <div className="absolute border border-black-900 border-solid h-[58px] inset-[0] justify-center m-auto rounded-[29px] w-full"></div>
              </div>
              <div className="h-[58px] relative w-full">
                <Text
                  className="mt-[3px] mx-auto sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                  size="txtPoppinsBold28Gray800"
                >
                  Shontelle
                </Text>
                <div className="absolute border border-black-900 border-solid h-[58px] inset-[0] justify-center m-auto rounded-[29px] w-full"></div>
              </div>
              <div className="h-[58px] relative w-full">
                <Text
                  className="mt-1.5 mx-auto sm:text-2xl md:text-[26px] text-[28px] text-center text-gray-800 tracking-[0.28px]"
                  size="txtPoppinsBold28Gray800"
                >
                  Annah
                </Text>
                <div className="absolute border border-black-900 border-solid h-[58px] inset-[0] justify-center m-auto rounded-[29px] w-full"></div>
              </div>
            </List>
            <Text
              className="md:ml-[0] ml-[619px] mt-[89px] sm:text-4xl md:text-[38px] text-[40px] text-black-900_01"
              size="txtRubikRomanMedium40"
            >
              Add Products{" "}
            </Text>
            <div className="flex sm:flex-col flex-row sm:gap-10 items-center justify-between max-w-[1385px] mt-12 mx-auto md:px-5 w-full">
              <Img
                className="h-[310px] md:h-auto sm:mt-0 mt-[11px] object-cover rounded-[30px]"
                src="images/img_frame44.png"
                alt="frameFortyFour"
              />
              <Img
                className="h-[310px] md:h-auto mb-[7px] sm:mt-0 mt-1 object-cover rounded-[30px]"
                src="images/img_frame45.png"
                alt="frameFortyFive"
              />
              <Img
                className="h-[310px] md:h-auto mb-[11px] object-cover rounded-[30px]"
                src="images/img_frame46.png"
                alt="frameFortySix"
              />
              <Img
                className="h-[310px] md:h-auto mb-[11px] object-cover rounded-[30px]"
                src="images/img_frame47.png"
                alt="frameFortySeven"
              />
            </div>
            <div className="flex md:flex-col flex-row font-poppins md:gap-5 items-start justify-end md:ml-[0] ml-[402px] mt-[29px] md:px-5 w-[66%] md:w-full">
              <Text
                className="leading-[1.00px] md:leading-[1px] md:mt-0 mt-1 text-center text-gray-800 text-xl tracking-[0.20px]"
                size="txtPoppinsBold20"
              >
                <span className="text-gray-800 font-poppins font-bold">
                  <>
                    Lipstick
                    <br />
                  </>
                </span>
                <span className="text-gray-800 font-poppins font-normal">
                  <>
                    Pink Alba
                    <br />
                  </>
                </span>
                <span className="text-red-600 font-poppins font-normal">
                  R 10.00
                </span>
              </Text>
              <Text
                className="leading-[1.00px] md:leading-[1px] mb-1 md:ml-[0] ml-[101px] text-center text-gray-800 text-xl tracking-[0.20px]"
                size="txtPoppinsBold20"
              >
                <span className="text-gray-800 font-poppins font-bold">
                  <>
                    Lipstick
                    <br />
                  </>
                </span>
                <span className="text-gray-800 font-poppins font-normal">
                  <>
                    Pink Alba
                    <br />
                  </>
                </span>
                <span className="text-red-600 font-poppins font-normal">
                  R 10.00
                </span>
              </Text>
              <Text
                className="leading-[1.00px] md:leading-[1px] mb-1 md:ml-[0] ml-[100px] text-center text-gray-800 text-xl tracking-[0.20px]"
                size="txtPoppinsBold20"
              >
                <span className="text-gray-800 font-poppins font-bold">
                  <>
                    Lipstick
                    <br />
                  </>
                </span>
                <span className="text-gray-800 font-poppins font-normal">
                  <>
                    Pink Alba
                    <br />
                  </>
                </span>
                <span className="text-red-600 font-poppins font-normal">
                  R 10.00
                </span>
              </Text>
            </div>
            <div className="flex md:flex-col flex-row md:gap-10 items-end justify-between max-w-[1219px] mt-14 mx-auto md:px-5 w-full">
              <div className="bg-blue_gray-100 flex md:flex-1 flex-row font-rubik sm:gap-10 items-center justify-between p-[22px] sm:px-5 rounded-[43px] w-[46%] md:w-full">
                <Text
                  className="ml-[15px] my-0.5 md:text-3xl sm:text-[28px] text-[32px] text-center text-gray-800"
                  size="txtRubikRomanMedium32"
                >
                  Select date and time
                </Text>
                <Img
                  className="h-[34px] md:h-auto mr-[58px] object-cover w-[33px]"
                  src="images/img_image1.png"
                  alt="imageOne"
                />
              </div>
              <Button
                className="cursor-pointer font-medium font-poppins h-[76px] md:mt-0 mt-[9px] rounded-[38px] text-4xl sm:text-[32px] md:text-[34px] text-center w-[388px]"
                size="xs"
              >
                Book Now
              </Button>
            </div>
            <Text
              className="md:ml-[0] ml-[643px] mt-[78px] sm:text-4xl md:text-[38px] text-[40px] text-black-900_01"
              size="txtRubikRomanMedium40"
            >
              About Us
            </Text>
            <Text
              className="leading-[53.00px] md:ml-[0] ml-[214px] mt-12 sm:text-[23px] md:text-[25px] text-[27px] text-blue_gray-900 text-center w-[81%] sm:w-full"
              size="txtPoppinsMedium27"
            >
              Welcome to Luminous Beauty, where we believe in the transformative
              power of beauty and the importance of self-care. Nestled in the
              heart of the city, our salon is a sanctuary of tranquility and
              luxury, where every visit promises an unparalleled experience of
              rejuvenation and refinement.
            </Text>
            <div className="flex sm:flex-col flex-row font-rubik sm:gap-10 items-start justify-between max-w-[1006px] mt-[124px] mx-auto md:px-5 w-full">
              <Text
                className="sm:mt-0 mt-[7px] sm:text-4xl md:text-[38px] text-[40px] text-black-900_01"
                size="txtRubikRomanMedium40"
              >
                Trading times
              </Text>
              <Text
                className="mb-[7px] sm:text-4xl md:text-[38px] text-[40px] text-black-900_01"
                size="txtRubikRomanMedium40"
              >
                Our location
              </Text>
            </div>
            <div className="flex md:flex-col flex-row font-rubik md:gap-[43px] items-center justify-between max-w-[1351px] mt-[11px] mx-auto md:px-5 w-full">
              <div className="bg-blue_gray-900_01 flex flex-col items-center justify-end md:mt-0 mt-1 p-3 rounded-[32px]">
                <Text
                  className="leading-[60.00px] mt-1 text-4xl sm:text-[32px] md:text-[34px] text-center text-white-A700"
                  size="txtRubikRomanMedium36"
                >
                  <>
                    Working Hours
                    <br />
                    Monday 09:00 AM - 11:00 PM
                    <br />
                    Tuesday 09:00 AM - 11:00 PM
                    <br />
                    Wednesday 09:00 AM - 11:00 PM
                    <br />
                    Thursday 09:00 AM - 11:00 PM
                    <br />
                    Friday 09:00 AM - 11:00 PM
                    <br />
                    Saturday 09:00 AM - 11:00 PM
                  </>
                </Text>
              </div>
              <Img
                className="h-[513px] md:h-auto object-cover rounded-[34px]"
                src="images/img_rectangle25.png"
                alt="rectangleTwentyFive"
              />
            </div>
            <div className="flex md:flex-col flex-row md:gap-10 gap-[73px] items-start justify-start md:ml-[0] ml-[67px] mt-[122px] md:px-5 w-[86%] md:w-full">
              <Img
                className="h-[581px] sm:h-auto object-cover w-[51%] md:w-full"
                src="images/img_rectangle21.png"
                alt="rectangleTwentyOne"
              />
              <div className="flex flex-col items-start justify-start md:mt-0 mt-1 w-[44%] md:w-full">
                <Text
                  className="text-lg text-red-A400 tracking-[2.88px]"
                  size="txtPoppinsSemiBold18"
                >
                  WHAT THEY SAY
                </Text>
                <Text
                  className="leading-[60.00px] mt-[22px] sm:text-[35px] md:text-[41px] text-[45px] text-black-900_01 w-full"
                  size="txtRubikRomanBold45"
                >
                  What Our Customers Say About Us
                </Text>
                <div className="font-poppins h-[124px] md:ml-[0] ml-[5px] relative w-[95%] sm:w-full">
                  <Img
                    className="h-[15px] ml-auto mr-[78px] mt-[50px] rounded-[3px] w-[15px]"
                    src="images/img_user.svg"
                    alt="user"
                  />
                  <Text
                    className="absolute h-full inset-[0] justify-center leading-[30.00px] m-auto text-blue_gray-900 text-xl w-full"
                    size="txtPoppinsMedium20"
                  >
                    <>
                      &quot;Absolutely amazing! The salon booking system has
                      revolutionized my beauty routine. No more waiting on hold
                      or playing phone tag to secure an appointment. With just a
                      few clicks, I can book my preferred services, select my
                      favorite stylist, and choose a convenient time slot—all
                      from the comfort of my home.
                    </>
                  </Text>
                </div>
                <div className="flex flex-row font-poppins gap-3.5 items-start justify-start md:ml-[0] ml-[5px] mt-[110px] w-[45%] md:w-full">
                  <Img
                    className="h-16 md:h-auto rounded-[50%] w-16"
                    src="images/img_ellipse9.png"
                    alt="ellipseNine"
                  />
                  <div className="flex flex-col items-start justify-start">
                    <Text
                      className="text-black-900 text-xl"
                      size="txtPoppinsMedium20Black900"
                    >
                      Theresa Jordan
                    </Text>
                    <Text
                      className="mt-[3px] text-base text-gray-600"
                      size="txtPoppinsMedium16Gray600"
                    >
                      Food Enthusiast
                    </Text>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex md:flex-col flex-row font-rubik md:gap-5 items-center justify-start max-w-[1188px] mt-[110px] mx-auto md:px-5 w-full">
              <div className="flex md:flex-1 flex-row gap-[19px] items-center justify-start mb-1.5 w-[13%] md:w-full">
                <div className="bg-red-A400 flex flex-col font-poppins h-[45px] items-center justify-start p-[3px] w-[45px]">
                  <div className="flex flex-col items-center justify-start w-[65%] md:w-full">
                    <div className="flex flex-row items-center justify-evenly w-full">
                      <div className="flex flex-col items-start justify-start">
                        <Text
                          className="text-gray-100 text-xs"
                          size="txtPoppinsBold12"
                        >
                          F
                        </Text>
                        <Text
                          className="text-gray-100 text-xs"
                          size="txtPoppinsBold12"
                        >
                          D
                        </Text>
                      </div>
                      <div className="md:h-[19px] h-[37px] relative w-[44%]">
                        <Text
                          className="absolute right-[0] text-gray-100 text-xs top-[0]"
                          size="txtPoppinsBold12"
                        >
                          O
                        </Text>
                        <Text
                          className="absolute bottom-[0] left-[0] text-gray-100 text-xs"
                          size="txtPoppinsBold12"
                        >
                          O
                        </Text>
                      </div>
                    </div>
                  </div>
                </div>
                <Text
                  className="text-2xl md:text-[22px] text-black-900 sm:text-xl"
                  size="txtRubikRomanSemiBold24"
                >
                  Foodeli
                </Text>
              </div>
              <Text
                className="md:ml-[0] ml-[235px] text-black-900 text-xl"
                size="txtRubikRomanSemiBold20"
              >
                About
              </Text>
              <Text
                className="md:ml-[0] ml-[97px] text-black-900 text-xl"
                size="txtRubikRomanSemiBold20"
              >
                Company
              </Text>
              <a
                href="javascript:"
                className="md:ml-[0] ml-[122px] text-black-900 text-xl"
              >
                <Text size="txtRubikRomanSemiBold20">Support</Text>
              </a>
              <Text
                className="md:ml-[0] ml-[134px] text-black-900 text-xl"
                size="txtRubikRomanSemiBold20"
              >
                Get in Touch
              </Text>
              <Img
                className="h-[15px] md:ml-[0] ml-[77px] rounded-[3px] w-[15px]"
                src="images/img_user.svg"
                alt="user_One"
              />
            </div>
            <div className="flex md:flex-col flex-row font-poppins gap-[49px] items-center justify-start max-w-[1217px] mt-[9px] mx-auto md:px-5 w-full">
              <Text
                className="sm:flex-1 leading-[30.00px] text-base text-blue_gray-900 w-[28%] sm:w-full"
                size="txtPoppinsMedium16Bluegray900"
              >
                Welcome to Dollup, your ultimate beauty companion designed to
                make your salon experience seamless and stress-free
              </Text>
              <div className="flex md:flex-1 flex-col items-start justify-start w-[69%] md:w-full">
                <div className="flex md:flex-col flex-row md:gap-5 items-center justify-start w-[96%] md:w-full">
                  <Text
                    className="text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    About Us
                  </Text>
                  <Text
                    className="md:ml-[0] ml-[85px] text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Vouchers
                  </Text>
                  <Text
                    className="md:ml-[0] ml-[138px] text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Account
                  </Text>
                  <Text
                    className="md:ml-[0] ml-[147px] text-blue_gray-900 text-lg"
                    size="txtPoppinsMedium18"
                  >
                    Question or feedback?
                  </Text>
                </div>
                <div className="flex sm:flex-col flex-row sm:gap-5 items-start justify-start mt-[13px] w-full">
                  <a
                    href="javascript:"
                    className="text-base text-blue_gray-900"
                  >
                    <Text size="txtPoppinsMedium16Bluegray900">Contact US</Text>
                  </a>
                  <Text
                    className="sm:ml-[0] ml-[67px] sm:mt-0 mt-0.5 text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Register Salon
                  </Text>
                  <Text
                    className="sm:ml-[0] ml-[100px] text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    FAQ
                  </Text>
                  <Text
                    className="sm:ml-[0] ml-[182px] text-blue_gray-900 text-lg"
                    size="txtPoppinsMedium18"
                  >
                    We’d love to hear from you
                  </Text>
                </div>
                <div className="flex md:flex-col flex-row md:gap-5 items-start justify-start mt-[15px] w-[95%] md:w-full">
                  <Text
                    className="text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Help
                  </Text>
                  <Text
                    className="md:ml-[0] ml-[121px] text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Become a Partner
                  </Text>
                  <Text
                    className="md:ml-[0] ml-[69px] text-base text-blue_gray-900"
                    size="txtPoppinsMedium16Bluegray900"
                  >
                    Help
                  </Text>
                  <Input
                    name="frameTwentyFive"
                    placeholder="Email Address"
                    className="p-0 placeholder:text-black-900 text-base text-left w-full"
                    wrapClassName="flex md:ml-[0] ml-[180px] md:mt-0 mt-[17px] w-[196px] md:w-full"
                    type="email"
                    suffix={
                      <Img
                        className="mt-0.5 mb-px h-5 ml-[23px]"
                        src="images/img_carbonsend.svg"
                        alt="carbon:send"
                      />
                    }
                  ></Input>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default BookingPage;
